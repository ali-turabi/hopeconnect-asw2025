const OrphanUpdate = require('../models/OrphanUpdate');

exports.createUpdate = async (req, res) => {
  try {
    const { orphan_id, title, description, photo_url, created_by } = req.body;

    // Basic validation
    if (!orphan_id || !title || !description || !created_by) {
      return res.status(400).json({ 
        success: false,
        message: 'All fields (orphan_id, title, description, created_by) are required' 
      });
    }

    // Validate IDs are numbers if they should be
    if (isNaN(orphan_id) || isNaN(created_by)) {
      return res.status(400).json({
        success: false,
        message: 'orphan_id and created_by must be valid numbers'
      });
    }

    const updateId = await OrphanUpdate.create({
      orphan_id,
      title,
      description,
      photo_url: photo_url || null,
      created_by
    });

    res.status(201).json({
      success: true,
      message: 'Orphan update created successfully',
      updateId
    });
  } catch (error) {
    console.error('Error creating orphan update:', error);
    
    // Handle specific error cases
    let statusCode = 500;
    let message = 'Server error while creating orphan update';
    
    if (error.message.includes('Orphan with ID') || error.message.includes('User with ID')) {
      statusCode = 404;
      message = error.message;
    } else if (error.code === 'ER_NO_REFERENCED_ROW_2') {
      statusCode = 404;
      message = 'Referenced orphan or user not found';
    }

    res.status(statusCode).json({
      success: false,
      message
    });
  }
};

exports.getUpdatesByOrphanId = async (req, res) => {
  try {
    const { orphanId } = req.params;
    
    if (isNaN(orphanId)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid orphan ID format'
      });
    }

    const updates = await OrphanUpdate.findByOrphanId(orphanId);
    
    res.status(200).json({
      success: true,
      message: 'Updates retrieved successfully',
      data: updates
    });
  } catch (error) {
    console.error('Error fetching orphan updates:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching orphan updates'
    });
  }
};
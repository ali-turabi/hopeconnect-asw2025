const db = require('../config/db');

exports.addOrphan = (req, res) => {
    const { name, age, gender } = req.body;
    const { orphanage_id } = req.user;

    const query = 'INSERT INTO orphans (name, age, gender, orphanage_id) VALUES (?, ?, ?, ?)';
    db.query(query, [name, age, gender, orphanage_id], (err, result) => {
        if (err) return res.status(500).json({ error: 'Failed to add orphan' });

        res.status(201).json({ message: 'Orphan added successfully', orphanId: result.insertId });
    });
};

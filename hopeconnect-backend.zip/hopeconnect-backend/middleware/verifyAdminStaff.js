const jwt = require('jsonwebtoken');
const db = require('../config/db');

module.exports = (req, res, next) => {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Authorization token missing or invalid' });
    }

    const token = authHeader.split(' ')[1];

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const userId = decoded.id;

        const staffQuery = 'SELECT * FROM staff WHERE user_id = ?';
        db.query(staffQuery, [userId], (err, results) => {
            if (err) return res.status(500).json({ error: 'Database error' });
            if (results.length === 0) return res.status(403).json({ message: 'User is not staff' });

            const staff = results[0];
            if (staff.position !== 'admin') {
                return res.status(403).json({ message: 'Only admin staff can add orphans' });
            }

            req.user = {
                id: userId,
                orphanage_id: staff.orphanage_id
            };

            next();
        });
    } catch (err) {
        return res.status(401).json({ error: 'Invalid or expired token' });
    }
};

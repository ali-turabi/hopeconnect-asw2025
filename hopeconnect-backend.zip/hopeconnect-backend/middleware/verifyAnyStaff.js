// middleware/verifyAnyStaff.js
const jwt = require('jsonwebtoken');
const db = require('../config/db');

module.exports = async (req, res, next) => {
    try {
        const token = req.headers.authorization?.split(' ')[1];
        if (!token) return res.status(401).json({ error: 'Authorization token missing' });

        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        
        const [user] = await db.query(`
            SELECT u.user_id, u.user_type, s.staff_id, s.position, s.orphanage_id
            FROM users u
            LEFT JOIN staff s ON u.user_id = s.user_id
            WHERE u.user_id = ? AND u.is_active = 1
        `, [decoded.user_id]);

        if (!user.length || !user[0].staff_id) {
            return res.status(403).json({ error: 'Staff access required' });
        }

        req.user = {
            id: user[0].user_id,
            orphanage_id: user[0].orphanage_id,
            position: user[0].position
        };

        next();
    } catch (err) {
        console.error('Staff Verification Error:', err);
        res.status(401).json({ error: 'Authentication failed' });
    }
};
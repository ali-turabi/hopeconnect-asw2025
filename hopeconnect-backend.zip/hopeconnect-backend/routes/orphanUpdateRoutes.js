const express = require('express');
const router = express.Router();
const orphanUpdateController = require('../controllers/orphanUpdateController');

// Create new orphan update
router.post('/', orphanUpdateController.createUpdate);

// Get updates for an orphan
router.get('/:orphanId', orphanUpdateController.getUpdatesByOrphanId);

module.exports = router;
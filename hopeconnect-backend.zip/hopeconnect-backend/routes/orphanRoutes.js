// routes/orphanRoutes.js
const express = require('express');
const router = express.Router();

// Middleware
const verifyAdminStaff = require('../middleware/verifyAdminStaff');
const verifyAnyStaff = require('../middleware/verifyAnyStaff');

// Controllers
const {
  addOrphan,
  getAllOrphans,
  getOrphan,
  toggleActiveStatus,
  deleteOrphan,
  updateOrphanAdmin,
  getNonSponsoredOrphans,
} = require('../controllers/orphanController');

// Routes (MUST be in correct order!)
router.get('/available', verifyAnyStaff, getNonSponsoredOrphans); // ✅ Must come before `/:id`
router.post('/add', verifyAdminStaff, addOrphan);
router.get('/all', verifyAnyStaff, getAllOrphans);
router.get('/:id', verifyAnyStaff, getOrphan);
router.patch('/:id/status', verifyAdminStaff, toggleActiveStatus);
router.delete('/:id', verifyAdminStaff, deleteOrphan);
router.put('/:id', verifyAdminStaff, updateOrphanAdmin);

module.exports = router;
const express = require('express');
const router = express.Router();

const orphanController = require('../controllers/orphanController');
const verifyAdminStaff = require('../middleware/verifyAdminStaff');

// POST /api/orphans/add
router.post('/add', verifyAdminStaff, orphanController.addOrphan);

module.exports = router;

const express = require('express');
const router = express.Router();
const { addOrphan } = require('../controllers/orphanController');
const verifyAdminStaff = require('../middleware/verifyAdminStaff');

router.post('/add', verifyAdminStaff, async (req, res) => {
  try {
    // handle request and send response
    res.status(201).json({ message: 'Orphan added successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;

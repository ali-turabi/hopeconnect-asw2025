const db = require('../config/db');

class OrphanUpdate {
  static async orphanExists(orphan_id) {
    const [rows] = await db.execute(
      'SELECT 1 FROM orphans WHERE orphan_id = ? LIMIT 1',
      [orphan_id]
    );
    return rows.length > 0;
  }

  static async userExists(user_id) {
    const [rows] = await db.execute(
      'SELECT 1 FROM users WHERE user_id = ? LIMIT 1',
      [user_id]
    );
    return rows.length > 0;
  }

  static async create({ orphan_id, title, description, photo_url, created_by }) {
    try {
      // Verify references exist first
      const [orphanCheck] = await db.execute(
        'SELECT orphan_id FROM orphans WHERE orphan_id = ? LIMIT 1',
        [orphan_id]
      );
      
      const [userCheck] = await db.execute(
        'SELECT user_id FROM users WHERE user_id = ? LIMIT 1',
        [created_by]
      );

      if (orphanCheck.length === 0) {
        throw new Error(`Orphan with ID ${orphan_id} not found`);
      }
      if (userCheck.length === 0) {
        throw new Error(`User with ID ${created_by} not found`);
      }

      const [result] = await db.execute(
        'INSERT INTO orphan_updates (orphan_id, title, description, photo_url, created_by) VALUES (?, ?, ?, ?, ?)',
        [orphan_id, title, description, photo_url, created_by]
      );
      return result.insertId;
    } catch (error) {
      console.error('Database error in OrphanUpdate.create:', error);
      throw error;
    }
  }

  static async findByOrphanId(orphanId) {
    const [rows] = await db.execute(
      'SELECT * FROM orphan_updates WHERE orphan_id = ? ORDER BY created_at DESC',
      [orphanId]
    );
    return rows;
  }
}

module.exports = OrphanUpdate;
const db = require('../config/db');

// Add a new orphan to the database
exports.insertOrphan = async (orphanData) => {
    const [result] = await db.query(`INSERT INTO orphans SET ?`, [orphanData]);
    return result.insertId;
};
